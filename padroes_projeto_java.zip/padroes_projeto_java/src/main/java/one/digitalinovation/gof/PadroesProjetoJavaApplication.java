package one.digitalinovation.gof;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PadroesProjetoJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PadroesProjetoJavaApplication.class, args);
	}

}
